<?php
$current = basename($_SERVER['PHP_SELF']);
$user = getCurrentUser();
$initials = mb_strtoupper(mb_substr($user['ho_ten'], 0, 1));
?>
<aside class="sidebar">
  <div class="sidebar-brand">
    <div class="logo-wrap">
      <div class="logo-icon">🎓</div>
      <div>
        <h1>Quản lý<br>Sinh viên</h1>
        <p>v1.0 – 2025</p>
      </div>
    </div>
  </div>
  
  <nav class="sidebar-nav">
    <div class="nav-section-label">Tổng quan</div>
    <a href="index.php" class="nav-item <?= $current==='index.php' ? 'active' : '' ?>">
      <span class="icon">📊</span> Dashboard
    </a>
    
    <div class="nav-section-label" style="margin-top:12px">Sinh viên</div>
    <a href="sinh_vien.php" class="nav-item <?= $current==='sinh_vien.php' ? 'active' : '' ?>">
      <span class="icon">👨‍🎓</span> Danh sách sinh viên
    </a>
    <a href="them_sv.php" class="nav-item <?= $current==='them_sv.php' ? 'active' : '' ?>">
      <span class="icon">➕</span> Thêm sinh viên
    </a>
    
    <?php if (isAdmin()): ?>
    <div class="nav-section-label" style="margin-top:12px">Quản trị</div>
    <a href="khoa.php" class="nav-item <?= $current==='khoa.php' ? 'active' : '' ?>">
      <span class="icon">🏫</span> Quản lý Khoa
    </a>
    <a href="tai_khoan.php" class="nav-item <?= $current==='tai_khoan.php' ? 'active' : '' ?>">
      <span class="icon">👥</span> Tài khoản
    </a>
    <?php endif; ?>
  </nav>
  
  <div class="sidebar-footer">
    <div class="user-chip">
      <div class="user-avatar"><?= $initials ?></div>
      <div class="user-info">
        <div class="user-name"><?= htmlspecialchars($user['ho_ten']) ?></div>
        <div class="user-role"><?= $user['role'] === 'admin' ? '⭐ Admin' : '👤 User' ?></div>
      </div>
      <a href="logout.php" class="logout-btn" title="Đăng xuất">🚪</a>
    </div>
  </div>
</aside>

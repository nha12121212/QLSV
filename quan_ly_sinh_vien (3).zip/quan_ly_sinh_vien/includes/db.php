<?php
// Cấu hình kết nối database
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'quan_ly_sinh_vien');

function getDB() {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    if ($conn->connect_error) {
        die("❌ Kết nối thất bại: " . $conn->connect_error .
            "<br><b>Hãy chạy file <code>database.sql</code> trong phpMyAdmin trước!</b>");
    }
    $conn->set_charset("utf8mb4");
    return $conn;
}
